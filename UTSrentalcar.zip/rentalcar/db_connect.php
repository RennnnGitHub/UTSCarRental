<?php
$servername = "awseb-e-andsbzufav-stack-awsebrdsdatabase-kkooxy2kzdoo.cn4zzlmojlvv.us-east-1.rds.amazonaws.com";
$username = "uts";
$password = "password12345";
$dbname = "ORDERS"; 

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
